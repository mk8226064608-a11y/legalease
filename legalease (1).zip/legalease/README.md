# LegalEase: AI-Powered Legal Document Generator

A FastAPI project that generates legal documents (Employment Contract, NDA, Residential Lease)
from smart built-in templates. **No external API is called.** All content comes from local templates
plus the sample data bundled in `app/templates_data.py`.

## Features
- 3 document types with sample data (click **Load sample data**)
- Automatic key-terms summary table, computed values (e.g. lease end date) and blank placeholders for missing inputs
- Editable preview: click any heading, term or paragraph to change it
- Custom branding: logo, company name, font and accent colour
- Export to **PDF**, **DOCX** and **TXT**

## Run
```bash
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000  (interactive API docs at /docs)

## Structure
```
app/
  main.py            FastAPI routes
  generator.py       template filling + derived values
  templates_data.py  templates, fields and sample data (add new document types here)
  exporters.py       PDF (reportlab), DOCX (python-docx), TXT
  static/index.html  frontend
samples/             pre-generated example PDF/DOCX/TXT files
```

## API
| Method | Path | Purpose |
|---|---|---|
| GET | `/api/templates` | Document types and their form fields |
| GET | `/api/sample/{doc_type}` | Sample values |
| POST | `/api/generate` | `{doc_type, values}` -> structured document |
| POST | `/api/export/{pdf\|docx\|txt}` | Edited document + brand -> file |

## Adding a document type
Add an entry to `TEMPLATES` with `fields`, `key_terms`, `sections` (use `{field_key}` placeholders)
and `signatories`. The form, preview and exports pick it up automatically.

*Generated documents are templates, not legal advice.*
