"""LegalEase - FastAPI backend. Run:  uvicorn app.main:app --reload"""
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .exporters import EXPORTERS
from .generator import generate, list_templates, sample_values
from .templates_data import TEMPLATES

STATIC = Path(__file__).parent / "static"
app = FastAPI(title="LegalEase", description="Template-based legal document generator")


class GenerateRequest(BaseModel):
    doc_type: str
    values: dict = Field(default_factory=dict)


class Section(BaseModel):
    heading: str
    body: str


class Brand(BaseModel):
    company: str = ""
    font: str = "Times"
    color: str = "#1F3A5F"
    logo: Optional[str] = None  # data URL, e.g. data:image/png;base64,...


class ExportRequest(BaseModel):
    title: str
    key_terms: List[List[str]] = []
    sections: List[Section]
    signatories: List[List[str]] = []
    disclaimer: str = ""
    brand: Brand = Brand()


@app.get("/api/templates")
def templates():
    return list_templates()


@app.get("/api/sample/{doc_type}")
def sample(doc_type: str):
    if doc_type not in TEMPLATES:
        raise HTTPException(404, "Unknown document type")
    return sample_values(doc_type)


@app.post("/api/generate")
def generate_doc(req: GenerateRequest):
    if req.doc_type not in TEMPLATES:
        raise HTTPException(404, "Unknown document type")
    return generate(req.doc_type, req.values)


@app.post("/api/export/{fmt}")
def export(fmt: str, req: ExportRequest):
    if fmt not in EXPORTERS:
        raise HTTPException(400, "Format must be pdf, docx or txt")
    func, mime = EXPORTERS[fmt]
    data = func(req.model_dump(exclude={"brand"}), req.brand.model_dump())
    return Response(data, media_type=mime,
                    headers={"Content-Disposition": f'attachment; filename="legalease-document.{fmt}"'})


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")


app.mount("/static", StaticFiles(directory=STATIC), name="static")
