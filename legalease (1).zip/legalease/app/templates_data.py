"""
Built-in legal document templates + sample data.

Everything here is local: no external AI/API is called. Each template has:
  - fields:      form inputs (with a `sample` value used by "Load sample data")
  - title:       document title
  - key_terms:   (label, field_key) pairs rendered as an automatic summary table
  - sections:    (heading, body) where {field_key} placeholders are filled in
  - signatories: (role label, field_key holding the name)
Field types: text | textarea | date | number | money
"""

DISCLAIMER = (
    "This document was generated from a template for convenience and does not "
    "constitute legal advice. Have it reviewed by a qualified lawyer before signing."
)

TEMPLATES = {
    # ------------------------------------------------------------------ #
    "employment": {
        "name": "Employment Contract",
        "title": "EMPLOYMENT AGREEMENT",
        "fields": [
            {"key": "employer_name", "label": "Employer (company) name", "type": "text", "sample": "BrightPath Technologies Pvt. Ltd."},
            {"key": "employer_address", "label": "Employer address", "type": "text", "sample": "12 Anna Salai, Chennai, Tamil Nadu 600002"},
            {"key": "employee_name", "label": "Employee name", "type": "text", "sample": "Priya Raman"},
            {"key": "employee_address", "label": "Employee address", "type": "text", "sample": "45 Gandhi Road, Tambaram, Chennai 600045"},
            {"key": "job_title", "label": "Job title", "type": "text", "sample": "Software Engineer"},
            {"key": "work_location", "label": "Work location", "type": "text", "sample": "Chennai office (hybrid)"},
            {"key": "start_date", "label": "Start date", "type": "date", "sample": "2026-11-02"},
            {"key": "salary", "label": "Annual salary", "type": "money", "sample": "900000"},
            {"key": "probation_months", "label": "Probation (months)", "type": "number", "sample": "3"},
            {"key": "notice_days", "label": "Notice period (days)", "type": "number", "sample": "60"},
            {"key": "governing_law", "label": "Governing law", "type": "text", "sample": "the laws of India and the courts of Chennai, Tamil Nadu"},
        ],
        "key_terms": [
            ("Employer", "employer_name"), ("Employee", "employee_name"),
            ("Position", "job_title"), ("Start date", "start_date"),
            ("Annual salary", "salary"), ("Probation", "probation_months_text"),
            ("Notice period", "notice_days_text"),
        ],
        "sections": [
            ("1. Parties",
             "This Employment Agreement (the \"Agreement\") is made between {employer_name}, "
             "of {employer_address} (the \"Employer\"), and {employee_name}, of "
             "{employee_address} (the \"Employee\")."),
            ("2. Position and Duties",
             "The Employer appoints the Employee as {job_title}, commencing on {start_date}. "
             "The Employee shall perform the duties reasonably assigned by the Employer and "
             "shall devote their full working time and attention to the role.\n\n"
             "The Employee's primary place of work is: {work_location}. The Employer may "
             "reasonably change the work location on written notice."),
            ("3. Compensation",
             "The Employer shall pay the Employee a gross annual salary of {salary}, payable "
             "in equal monthly instalments, less applicable statutory deductions. Salary shall "
             "be reviewed annually at the Employer's discretion."),
            ("4. Probation",
             "The first {probation_months_text} of employment is a probationary period. During "
             "probation either party may end this Agreement on shorter notice as permitted by law."),
            ("5. Confidentiality",
             "The Employee shall keep confidential, during and after employment, all non-public "
             "information of the Employer, including business plans, client data, source code and "
             "financial information, and shall use it solely to perform their duties."),
            ("6. Intellectual Property",
             "All work product, inventions and materials created by the Employee in the course of "
             "employment shall belong exclusively to the Employer. The Employee assigns all related "
             "rights to the Employer."),
            ("7. Termination",
             "After probation, either party may terminate this Agreement by giving "
             "{notice_days_text} written notice. The Employer may terminate without notice for "
             "serious misconduct. On termination the Employee shall return all Employer property."),
            ("8. Governing Law",
             "This Agreement is governed by {governing_law}."),
        ],
        "signatories": [("Employer", "employer_name"), ("Employee", "employee_name")],
    },
    # ------------------------------------------------------------------ #
    "nda": {
        "name": "Non-Disclosure Agreement (NDA)",
        "title": "NON-DISCLOSURE AGREEMENT",
        "fields": [
            {"key": "disclosing_party", "label": "Disclosing party", "type": "text", "sample": "Pixel Orchard Studios (Client)"},
            {"key": "receiving_party", "label": "Receiving party", "type": "text", "sample": "Arjun Mehta (Freelance Designer)"},
            {"key": "effective_date", "label": "Effective date", "type": "date", "sample": "2026-10-10"},
            {"key": "purpose", "label": "Purpose of disclosure", "type": "textarea", "sample": "evaluating and delivering a mobile app redesign project"},
            {"key": "confidential_info", "label": "Confidential information covers", "type": "textarea", "sample": "product designs, source files, customer lists, pricing and unreleased features"},
            {"key": "term_years", "label": "Confidentiality term (years)", "type": "number", "sample": "3"},
            {"key": "governing_law", "label": "Governing law", "type": "text", "sample": "the laws of India"},
        ],
        "key_terms": [
            ("Disclosing party", "disclosing_party"), ("Receiving party", "receiving_party"),
            ("Effective date", "effective_date"), ("Term", "term_years_text"),
            ("Governing law", "governing_law"),
        ],
        "sections": [
            ("1. Parties and Purpose",
             "This Non-Disclosure Agreement is entered into on {effective_date} between "
             "{disclosing_party} (the \"Disclosing Party\") and {receiving_party} (the "
             "\"Receiving Party\"). The parties wish to exchange confidential information for the "
             "purpose of {purpose} (the \"Purpose\")."),
            ("2. Confidential Information",
             "\"Confidential Information\" means all non-public information disclosed by the "
             "Disclosing Party, in any form, including {confidential_info}, and any notes or "
             "analyses derived from it."),
            ("3. Obligations",
             "The Receiving Party shall (a) use Confidential Information only for the Purpose; "
             "(b) not disclose it to any third party without prior written consent; and (c) protect "
             "it with at least the same care it uses for its own confidential information, and no "
             "less than reasonable care."),
            ("4. Exclusions",
             "Confidential Information does not include information that is or becomes public "
             "through no fault of the Receiving Party, was already lawfully known to it, was "
             "independently developed, or is lawfully received from a third party."),
            ("5. Term",
             "The obligations in this Agreement continue for {term_years_text} from the "
             "effective date, and indefinitely for any trade secrets."),
            ("6. Return of Materials",
             "On request, the Receiving Party shall promptly return or destroy all Confidential "
             "Information and confirm in writing that it has done so."),
            ("7. Remedies and Governing Law",
             "The parties agree that breach may cause irreparable harm for which injunctive relief "
             "is appropriate in addition to other remedies. This Agreement is governed by {governing_law}."),
        ],
        "signatories": [("Disclosing Party", "disclosing_party"), ("Receiving Party", "receiving_party")],
    },
    # ------------------------------------------------------------------ #
    "lease": {
        "name": "Residential Lease Agreement",
        "title": "RESIDENTIAL LEASE AGREEMENT",
        "fields": [
            {"key": "landlord_name", "label": "Landlord name", "type": "text", "sample": "Suresh Kumar"},
            {"key": "tenant_name", "label": "Tenant name", "type": "text", "sample": "Divya Lakshmi"},
            {"key": "property_address", "label": "Property address", "type": "text", "sample": "Flat 3B, Lotus Residency, Velachery Main Road, Chennai 600042"},
            {"key": "lease_start", "label": "Lease start date", "type": "date", "sample": "2026-11-01"},
            {"key": "lease_term_months", "label": "Lease term (months)", "type": "number", "sample": "11"},
            {"key": "monthly_rent", "label": "Monthly rent", "type": "money", "sample": "22000"},
            {"key": "security_deposit", "label": "Security deposit", "type": "money", "sample": "110000"},
            {"key": "rent_due_day", "label": "Rent due day of month", "type": "number", "sample": "5"},
            {"key": "governing_law", "label": "Governing law", "type": "text", "sample": "the laws of India and the courts of Chennai, Tamil Nadu"},
        ],
        "key_terms": [
            ("Landlord", "landlord_name"), ("Tenant", "tenant_name"),
            ("Property", "property_address"), ("Term", "lease_term_text"),
            ("Start / end", "lease_period"), ("Monthly rent", "monthly_rent"),
            ("Security deposit", "security_deposit"),
        ],
        "sections": [
            ("1. Parties and Property",
             "This Lease Agreement is made between {landlord_name} (the \"Landlord\") and "
             "{tenant_name} (the \"Tenant\"). The Landlord leases to the Tenant the residential "
             "premises at {property_address} (the \"Property\")."),
            ("2. Term",
             "The lease runs for {lease_term_text}, beginning on {lease_start} and ending on "
             "{lease_end}, unless renewed in writing by both parties."),
            ("3. Rent",
             "The Tenant shall pay rent of {monthly_rent} per month, in advance, on or before "
             "day {rent_due_day} of each month, by bank transfer or another method agreed in writing."),
            ("4. Security Deposit",
             "On signing, the Tenant shall pay a refundable security deposit of {security_deposit}. "
             "The Landlord shall return it within 30 days after the Tenant vacates, less lawful "
             "deductions for unpaid rent or damage beyond normal wear and tear."),
            ("5. Use of Property",
             "The Property shall be used only as a private residence. The Tenant shall keep it clean, "
             "avoid nuisance to neighbours, and not sublet or alter it without the Landlord's written consent."),
            ("6. Maintenance and Utilities",
             "The Tenant pays for electricity, water, internet and other utilities used. The Landlord "
             "is responsible for structural repairs; the Tenant is responsible for minor day-to-day upkeep."),
            ("7. Termination",
             "Either party may terminate this Lease before the end of the term by giving one month's "
             "written notice. The Landlord may terminate immediately for material breach, including "
             "non-payment of rent after written notice."),
            ("8. Governing Law",
             "This Lease is governed by {governing_law}."),
        ],
        "signatories": [("Landlord", "landlord_name"), ("Tenant", "tenant_name")],
    },
}
