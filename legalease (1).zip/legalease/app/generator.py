"""Local, deterministic document generator (no external API calls)."""
import calendar
from datetime import date, datetime, timedelta

from .templates_data import DISCLAIMER, TEMPLATES

BLANK = "[__________]"


def _fmt_date(value: str) -> str:
    try:
        return datetime.strptime(value, "%Y-%m-%d").strftime("%d %B %Y")
    except (ValueError, TypeError):
        return value


def _fmt_money(value: str) -> str:
    try:
        return f"INR {float(value):,.0f}"
    except (ValueError, TypeError):
        return value


def _plural(n: str, unit: str) -> str:
    try:
        k = int(float(n))
        return f"{k} {unit}{'' if k == 1 else 's'}"
    except (ValueError, TypeError):
        return n


def _add_months(start: date, months: int) -> date:
    """Last day of a lease that starts on `start` and runs `months` months."""
    idx = start.month - 1 + months
    year, month = start.year + idx // 12, idx % 12 + 1
    day = min(start.day, calendar.monthrange(year, month)[1])
    return date(year, month, day) - timedelta(days=1)


def list_templates() -> dict:
    return {
        tid: {"name": t["name"], "fields": t["fields"]} for tid, t in TEMPLATES.items()
    }


def sample_values(doc_type: str) -> dict:
    return {f["key"]: f["sample"] for f in TEMPLATES[doc_type]["fields"]}


def _context(doc_type: str, values: dict) -> dict:
    tpl = TEMPLATES[doc_type]
    ctx = {}
    for f in tpl["fields"]:
        raw = str(values.get(f["key"], "")).strip()
        if not raw:
            ctx[f["key"]] = BLANK
        elif f["type"] == "date":
            ctx[f["key"]] = _fmt_date(raw)
        elif f["type"] == "money":
            ctx[f["key"]] = _fmt_money(raw)
        else:
            ctx[f["key"]] = raw

    def raw_of(key):
        return str(values.get(key, "")).strip()

    # derived values
    if doc_type == "employment":
        ctx["probation_months_text"] = _plural(raw_of("probation_months"), "month") if raw_of("probation_months") else BLANK
        ctx["notice_days_text"] = _plural(raw_of("notice_days"), "day") if raw_of("notice_days") else BLANK
    elif doc_type == "nda":
        ctx["term_years_text"] = _plural(raw_of("term_years"), "year") if raw_of("term_years") else BLANK
    elif doc_type == "lease":
        months = raw_of("lease_term_months")
        ctx["lease_term_text"] = _plural(months, "month") if months else BLANK
        try:
            start = datetime.strptime(raw_of("lease_start"), "%Y-%m-%d").date()
            end = _add_months(start, int(float(months)))
            ctx["lease_end"] = end.strftime("%d %B %Y")
        except (ValueError, TypeError):
            ctx["lease_end"] = BLANK
        ctx["lease_period"] = f"{ctx['lease_start']} to {ctx['lease_end']}"
    return ctx


def generate(doc_type: str, values: dict) -> dict:
    """Return a structured, editable document."""
    if doc_type not in TEMPLATES:
        raise KeyError(doc_type)
    tpl = TEMPLATES[doc_type]
    ctx = _context(doc_type, values)
    return {
        "doc_type": doc_type,
        "title": tpl["title"],
        "key_terms": [[label, ctx.get(key, BLANK)] for label, key in tpl["key_terms"]],
        "sections": [
            {"heading": h, "body": body.format_map(ctx)} for h, body in tpl["sections"]
        ],
        "signatories": [[role, ctx.get(key, BLANK)] for role, key in tpl["signatories"]],
        "disclaimer": DISCLAIMER,
    }
