"""Export an (edited) document to TXT, DOCX and PDF with custom branding."""
import base64
import io
import re
from xml.sax.saxutils import escape

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (HRFlowable, Image, KeepTogether, Paragraph,
                                SimpleDocTemplate, Spacer, Table, TableStyle)

FONTS = {  # key -> (reportlab regular, reportlab bold, Word font)
    "Helvetica": ("Helvetica", "Helvetica-Bold", "Arial"),
    "Times": ("Times-Roman", "Times-Bold", "Times New Roman"),
    "Courier": ("Courier", "Courier-Bold", "Courier New"),
}


def _font(brand):
    return FONTS.get((brand or {}).get("font"), FONTS["Times"])


def _hex(brand):
    c = (brand or {}).get("color", "")
    return c.lstrip("#") if re.fullmatch(r"#?[0-9a-fA-F]{6}", c or "") else "1F3A5F"


def _logo_bytes(brand):
    data = (brand or {}).get("logo")
    if not data or "," not in data:
        return None
    try:
        return base64.b64decode(data.split(",", 1)[1])
    except Exception:
        return None


# ------------------------------------------------------------------ TXT
def to_txt(doc: dict, brand: dict) -> bytes:
    lines = []
    company = (brand or {}).get("company", "").strip()
    if company:
        lines += [company.upper(), ""]
    lines += [doc["title"], "=" * len(doc["title"]), ""]
    if doc.get("key_terms"):
        lines.append("KEY TERMS")
        for k, v in doc["key_terms"]:
            lines.append(f"  {k}: {v}")
        lines.append("")
    for s in doc["sections"]:
        lines += [s["heading"], s["body"], ""]
    lines.append("SIGNATURES")
    for role, name in doc.get("signatories", []):
        lines += ["", "_" * 36, f"{role}: {name}", "Date: ______________"]
    lines += ["", doc.get("disclaimer", "")]
    return "\n".join(lines).encode("utf-8")


# ------------------------------------------------------------------ DOCX
def _shade(cell, hex_fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_fill)
    tcPr.append(shd)


def to_docx(doc: dict, brand: dict) -> bytes:
    _, _, word_font = _font(brand)
    accent = RGBColor.from_string(_hex(brand).upper())
    d = Document()
    sec = d.sections[0]
    sec.page_width, sec.page_height = Inches(8.27), Inches(11.69)  # A4
    sec.left_margin = sec.right_margin = Inches(1)

    normal = d.styles["Normal"]
    normal.font.name = word_font
    normal.font.size = Pt(11)
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), word_font)

    logo = _logo_bytes(brand)
    if logo:
        p = d.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        try:
            p.add_run().add_picture(io.BytesIO(logo), height=Inches(0.8))
        except Exception:
            pass
    company = (brand or {}).get("company", "").strip()
    if company:
        p = d.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(company)
        r.bold, r.font.size, r.font.color.rgb = True, Pt(12), accent

    p = d.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before, p.paragraph_format.space_after = Pt(12), Pt(14)
    r = p.add_run(doc["title"])
    r.bold, r.font.size, r.font.color.rgb = True, Pt(18), accent

    if doc.get("key_terms"):
        t = d.add_table(rows=0, cols=2)
        t.style = "Table Grid"
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for k, v in doc["key_terms"]:
            row = t.add_row().cells
            row[0].width, row[1].width = Inches(1.9), Inches(4.4)
            row[0].text, row[1].text = "", v
            rr = row[0].paragraphs[0].add_run(k)
            rr.bold = True
            _shade(row[0], "EEF2F7")
        d.add_paragraph()

    for s in doc["sections"]:
        p = d.add_paragraph()
        p.paragraph_format.space_before, p.paragraph_format.space_after = Pt(10), Pt(3)
        p.paragraph_format.keep_with_next = True
        r = p.add_run(s["heading"])
        r.bold, r.font.size, r.font.color.rgb = True, Pt(12), accent
        for para in [x for x in s["body"].split("\n") if x.strip()]:
            bp = d.add_paragraph(para.strip())
            bp.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            bp.paragraph_format.space_after = Pt(6)

    p = d.add_paragraph()
    p.paragraph_format.space_before = Pt(18)
    p.paragraph_format.keep_with_next = True
    r = p.add_run("SIGNATURES")
    r.bold, r.font.color.rgb = True, accent
    sigs = doc.get("signatories", [])
    if sigs:
        t = d.add_table(rows=1, cols=len(sigs))
        for i, (role, name) in enumerate(sigs):
            c = t.rows[0].cells[i]
            c.text = ""
            c.paragraphs[0].add_run("\n\n______________________________")
            c.add_paragraph().add_run(role).bold = True
            c.add_paragraph(name)
            c.add_paragraph("Date: ________________")
    note = d.add_paragraph()
    note.paragraph_format.space_before = Pt(18)
    nr = note.add_run(doc.get("disclaimer", ""))
    nr.italic, nr.font.size, nr.font.color.rgb = True, Pt(8.5), RGBColor(0x66, 0x66, 0x66)

    buf = io.BytesIO()
    d.save(buf)
    return buf.getvalue()


# ------------------------------------------------------------------ PDF
def to_pdf(doc: dict, brand: dict) -> bytes:
    reg, bold, _ = _font(brand)
    accent = colors.HexColor("#" + _hex(brand))
    company = (brand or {}).get("company", "").strip()

    body = ParagraphStyle("body", fontName=reg, fontSize=10.5, leading=15, alignment=TA_JUSTIFY, spaceAfter=6)
    head = ParagraphStyle("head", fontName=bold, fontSize=12, leading=15, textColor=accent, spaceBefore=10, spaceAfter=3, keepWithNext=True)
    title = ParagraphStyle("title", fontName=bold, fontSize=19, leading=24, textColor=accent, alignment=TA_CENTER, spaceBefore=6, spaceAfter=14)
    center = ParagraphStyle("center", parent=body, alignment=TA_CENTER, fontName=bold, textColor=accent, fontSize=12)
    small = ParagraphStyle("small", fontName=reg, fontSize=8.5, leading=11, textColor=colors.HexColor("#666666"))
    cell = ParagraphStyle("cell", fontName=reg, fontSize=10, leading=13)
    cellb = ParagraphStyle("cellb", parent=cell, fontName=bold)

    def para(text, style):
        return Paragraph(escape(text).replace("\n", "<br/>"), style)

    story = []
    raw = _logo_bytes(brand)
    if raw:
        try:
            iw, ih = ImageReader(io.BytesIO(raw)).getSize()
            h = min(0.8 * inch, 2.2 * inch * ih / iw)
            w = h * iw / ih
            img = Image(io.BytesIO(raw), width=w, height=h)
            img.hAlign = "CENTER"
            story += [img, Spacer(1, 6)]
        except Exception:
            pass
    if company:
        story.append(para(company, center))
    story += [para(doc["title"], title)]

    if doc.get("key_terms"):
        rows = [[para(k, cellb), para(v, cell)] for k, v in doc["key_terms"]]
        t = Table(rows, colWidths=[1.7 * inch, 4.6 * inch])
        t.setStyle(TableStyle([
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#B8C2CF")),
            ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#EEF2F7")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story += [t, Spacer(1, 8)]

    for s in doc["sections"]:
        block = [para(s["heading"], head)]
        parts = [x.strip() for x in s["body"].split("\n") if x.strip()]
        block += [para(x, body) for x in parts]
        story.append(KeepTogether(block[:2]))
        story += block[2:]

    sigs = doc.get("signatories", [])
    if sigs:
        cells = [[para(f"{role}\n{name}\nDate: ________________", cell) for role, name in sigs]]
        st = Table(cells, colWidths=[3.15 * inch] * len(sigs), rowHeights=[0.9 * inch])
        st.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "BOTTOM"), ("LINEABOVE", (0, 0), (-1, 0), 0.8, colors.black)]))
        story.append(KeepTogether([Spacer(1, 22), para("SIGNATURES", head), Spacer(1, 18), st]))
    story += [Spacer(1, 14), HRFlowable(width="100%", color=colors.HexColor("#CCCCCC")), Spacer(1, 4), para(doc.get("disclaimer", ""), small)]

    def footer(canvas, _doc):
        canvas.saveState()
        canvas.setFont(reg, 8.5)
        canvas.setFillColor(colors.HexColor("#777777"))
        canvas.drawString(inch, 0.55 * inch, company or doc["title"])
        canvas.drawRightString(A4[0] - inch, 0.55 * inch, f"Page {canvas.getPageNumber()}")
        canvas.restoreState()

    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=A4, leftMargin=inch, rightMargin=inch, topMargin=0.9 * inch,
                      bottomMargin=0.9 * inch, title=doc["title"], author=company or "LegalEase").build(
        story, onFirstPage=footer, onLaterPages=footer)
    return buf.getvalue()


EXPORTERS = {
    "pdf": (to_pdf, "application/pdf"),
    "docx": (to_docx, "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    "txt": (to_txt, "text/plain; charset=utf-8"),
}
